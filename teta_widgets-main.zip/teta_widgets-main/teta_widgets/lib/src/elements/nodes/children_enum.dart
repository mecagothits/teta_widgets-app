// ignore_for_file: public_member_api_docs

enum ChildrenEnum {
  none,
  child,
  children,
}
