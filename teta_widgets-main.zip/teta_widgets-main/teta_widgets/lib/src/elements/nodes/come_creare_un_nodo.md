# Come creare un nuovo nodo

Hey!
Qui troverai la spiegazione per aggiungere un nuovo nodo su Teta.

Questa sezione è ancora in work in progress.