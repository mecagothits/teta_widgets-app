// ignore_for_file: public_member_api_docs

enum NodeCategories {
  unclassified,
  basic,
  advanced,
  space,
  list,
  input,
  map,
  firebase,
  supabase,
  revenueCat,
  wordpress,
  logic,
  navigation,
  responsive,
  experimental,
  animated,
}
