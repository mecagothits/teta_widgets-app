// ignore_for_file: public_member_api_docs

enum ActionNavigation {
  goBack,
  openDrawer,
  launchURL,
  openPage,
  openBottomSheet,
  openSnackBar,
  openDatePicker,
}
