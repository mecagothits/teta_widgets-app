/// [ActionAudioPlayer] identifies audio player actions
// ignore_for_file: public_member_api_docs

enum ActionAudioPlayer {
  play,
  pause,
  reload,
  loopOff,
  loopOne,
  loopAll,
}
