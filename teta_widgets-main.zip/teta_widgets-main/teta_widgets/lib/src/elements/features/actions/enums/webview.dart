/// [ActionWebView] identifies webview actions
// ignore_for_file: public_member_api_docs

enum ActionWebView {
  reload,
  goBack,
  goForward,
}
