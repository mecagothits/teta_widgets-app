// Package imports:
// ignore_for_file: public_member_api_docs

// Package imports:
import 'package:intl/intl.dart';

class FTextDirection {
  /// Set of funcs to use TextDirection within Teta
  FTextDirection({
    final TextDirection dir = TextDirection.LTR,
  }) : _dir = dir;

  TextDirection _dir;

  TextDirection get get => _dir;

  String get getStringForDropDown => _convertValueToDropDown(_dir);

  void set(final String value) => _dir = _convertDropDownToValue(value);

  static FTextDirection fromJson(final String? json) {
    if (json != null) {
      return FTextDirection(
        dir: _convertJsonToValue(json),
      );
    } else {
      return FTextDirection();
    }
  }

  String toJson() => _convertValueToJson(_dir);

  static TextDirection _convertJsonToValue(final String key) {
    if (key == 'r') return TextDirection.RTL;
    return TextDirection.LTR;
  }

  static TextDirection _convertDropDownToValue(final String key) {
    if (key == 'Right to Left') return TextDirection.RTL;
    return TextDirection.LTR;
  }

  static String _convertValueToDropDown(final TextDirection key) {
    if (key == TextDirection.RTL) return 'Right to Left';
    return 'Left to Right';
  }

  static String _convertValueToJson(final TextDirection value) {
    if (value == TextDirection.RTL) return 'r';
    return 'l';
  }

  static String _convertValueToCode(final TextDirection? value) {
    if (value == TextDirection.RTL) return 'TextDirection.RTL';
    return 'TextDirection.LTR';
  }

  String toCode() => _convertValueToCode(_dir);
}
