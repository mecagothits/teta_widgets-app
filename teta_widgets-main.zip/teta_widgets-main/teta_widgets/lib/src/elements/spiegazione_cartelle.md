# Elements

Hey!
Qui troverai tutti i file inerenti ai nodi.
Abbiamo le seguenti cartelle:

## Action
- actions: tutte le azioni di FAction, come il login con Google, incrementare uno stato al click, ecc.

## Bodies
- bodies: qui sarà possibile modificare le proprietà e la lista dei controlli di ciascun nodo

## Builder
- builder: file e classi che ci aiuteranno a diminuire le dimensioni degli altri file (quando una parte di codice viene ripetuta spesso, mettila qui)

## Controls
- controls: i controlli sono quelli che compaiono nella barra a destra

## Features
- features: sono le proprietà complesse che un nodo può avere. Es: FSize, FFill, FAlign, FAction, ecc.

## intrinsicState
- intrinsicState: composta da un unico file, esso rappresenta lo scheletro di tutti gli intrinsicState dei nodi

## Nodes
- nodes: troverai i nodi completi disponibili, il file node.dart (CNode) e il node_body.dart, che rappresenta lo scheletro di tutti i bodies in /bodies/

## Templates
- templates: attualmente non utilizzata, potrà essere usata per creare template (gruppi di widget) già prefatti

## Widgets
- widgets: la controparte Widget dei nodi. Essi sono quelli che compariranno nella preview del telefono su Teta e in modalità Play

